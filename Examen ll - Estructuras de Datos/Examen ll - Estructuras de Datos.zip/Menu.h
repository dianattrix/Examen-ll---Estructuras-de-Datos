#pragma once
#include <iostream>
#include "Grafo.h"
#include "IGrafo.h"
#include "GrafoDijkstra.h"
#include "GrafoKruskal.h"
#include "GrafoPrim.h"
#include "ParseGraph.h"
#include "WriteGraph.h"

using namespace std;

class Menu{
public: 
	void menuPrincipal();
};

